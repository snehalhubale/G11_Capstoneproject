-- the order of values is related to the name of field.
-- Updating is necessary, if the name is changed



INSERT INTO "public"."order_main" VALUES (2147483643, '3100 Western Road A', 'customer2@email.com', 'customer2', '2343456', '2018-03-15 12:52:20.439', 100.00, 0, '2018-03-15 12:52:20.439');
INSERT INTO "public"."order_main" VALUES (2147483645, '3100 Western Road A', 'customer2@email.com', 'customer2', '2343456', '2018-03-15 12:52:29.007', 4.00, 0, '2018-03-15 12:52:29.007');
INSERT INTO "public"."order_main" VALUES (2147483641, '3100 Western Road A', 'customer2@email.com', 'customer2', '2343456', '2018-03-15 12:52:07.428', 180.00, 2, '2018-03-15 12:52:53.664');
INSERT INTO "public"."order_main" VALUES (2147483647, '3100 Western Road A', 'customer2@email.com', 'customer2', '2343456', '2018-03-15 12:52:35.289', 2.00, 2, '2018-03-15 12:52:55.919');
INSERT INTO "public"."order_main" VALUES (2147483649, '3100 Western Road A', 'customer2@email.com', 'customer2', '2343456', '2018-03-15 12:58:23.824', 150.00, 0, '2018-03-15 12:58:23.824');
INSERT INTO "public"."order_main" VALUES (2147483642, '3200 West Road', 'customer1@email.com', 'customer1', '123456789', '2018-03-15 13:01:21.135', 4.00, 2, '2018-03-15 13:02:09.023');
INSERT INTO "public"."order_main" VALUES (2147483640, '3200 West Road', 'customer1@email.com', 'customer1', '123456789', '2018-03-15 13:01:16.271', 20.00, 2, '2018-03-15 13:02:52.067');
INSERT INTO "public"."order_main" VALUES (2147483648, '3200 West Road', 'customer1@email.com', 'customer1', '123456789', '2018-03-15 13:01:06.943', 134.00, 1, '2018-03-15 13:02:56.498');

-- ----------------------------
-- Table structure for product_category

-- ----------------------------
-- Records of product_category
-- ----------------------------
INSERT INTO "public"."product_category" VALUES (2147483641, 'Beds', 0, '2018-03-09 23:03:26', '2018-03-10 00:15:27');
INSERT INTO "public"."product_category" VALUES (2147483642, 'Chairs', 2, '2018-03-10 00:15:02', '2018-03-10 00:15:21');
INSERT INTO "public"."product_category" VALUES (2147483644, 'Sofas', 3, '2018-03-10 01:01:09', '2018-03-10 01:01:09');
INSERT INTO "public"."product_category" VALUES (2147483645, 'Carpets', 1, '2018-03-10 00:26:05', '2018-03-10 00:26:05');


-- ----------------------------
-- Records of product_in_order
-- ----------------------------
INSERT INTO "public"."product_in_order" VALUES (2147483642, 0,1,'One Step Closer To Comfort', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Web_Beds_Trends_01_2X_29042022.jpg', 'B0001', 'Dreamy Poster Bed', 30.00,96,NULL, 2147483641);
INSERT INTO "public"."product_in_order" VALUES (2147483644, 0,1, 'Have a Pleasent Sleep', 'https://ii1.pepperfry.com/media/wysiwyg/banners/Web_Beds_Trends_02_2X_29042022.jpg', 'B0002', 'Easylift', 20.00,195,NULL, 2147483643);
INSERT INTO "public"."product_in_order" VALUES (2147483646, 1,1, 'Have a Smooth walk', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Flooring_Trends_Web_2X_1_17032022.jpg', 'F0001', 'SoftyCarpet', 4.00,57,NULL, 2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483648, 3,1,'Comfort Zone', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Sofasrecliners_irb_web_24012022_2x_4.jpg', 'D0002', 'Two Seater Sofa', 2.00,200,NULL, 2147483647);
INSERT INTO "public"."product_in_order" VALUES (2147483640, 1,1, 'On Way To Comfort', 'https://ii1.pepperfry.com/media/wysiwyg/banners/Flooring_Trends_Web_2X_2_17032022.jpg', 'F0001', 'My Walk', 4.00,57,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483641, 2,1, 'Grab Your Chair', 'https://ii2.pepperfry.com/media/wysiwyg/banners/Testimonial_web_261221_9.jpg', 'C0002', 'Office Chair', 13.00,108,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483632, 1,1, 'Feel The Way', 'https://ii2.pepperfry.com/media/wysiwyg/banners/Flooring_Trends_Web_2X_3_17032022.jpg', 'F0002', 'Soft Carpets', 20.00,22,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483643, 0,1, 'Grab Your Dreams', 'https://ii2.pepperfry.com/media/wysiwyg/banners/Web_Beds_Trends_03_2X_29042022.jpg', 'B0001', 'Oh-So-Plush', 30.00,96,NULL, 2147483648);
INSERT INTO "public"."product_in_order" VALUES (2147483634, 2,1, 'Grab a Chair', 'https://ii1.pepperfry.com/media/wysiwyg/banners/Testimonial_web_261221_7.jpg', 'C0001', 'Wooden Chair', 10.00, 109,NULL, 2147483649);
INSERT INTO "public"."product_in_order" VALUES (2147483636, 0,1, 'My Comfort Zone', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Web_Beds_Trends_04_2X_29042022.jpg', 'B0005', 'Spine Loving', 30.00, 199,NULL,2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483647, 3,1, 'My Comfort Space', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Sofasrecliners_irb_web_24012022_2x_1.jpg', 'D0002', 'Three Seater Sofa', 2.00,200,NULL, 2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483638, 0,1, 'Have a Nice Sleep', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Beds_Room_Block_Mattresses_web_24012022_1.jpg', 'B0004', 'My Zone', 30.00,199,NULL, 2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483649, 0,1, 'Grab your Sleep', 'https://ii2.pepperfry.com/media/wysiwyg/banners/Web_Beds_Rooms_Bedroom_01_2X_29042022.jpg', 'B0001', 'MyBed', 30.00,  96,NULL,2147483645);
INSERT INTO "public"."product_in_order" VALUES (2147483631, 1,1, 'My Foot Prints', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Flooring_Trends_Web_2X_4_17032022.jpg', 'F0002', 'Hallway Runners', 20.00,  22,null ,2147483640);
INSERT INTO "public"."product_in_order" VALUES (2147483633, 1,1, 'Make Your Path', 'https://ii2.pepperfry.com/media/wysiwyg/banners/Flooring_Style_Web_2X_2_17032022.jpg', 'F0001', 'Cotton Carpets', 4.00, 57, null ,2147483642);


-- ----------------------------
-- Records of product_info
-- ----------------------------
INSERT INTO "public"."product_info" VALUES ('B0003', 0, '2018-03-10 10:37:39', 'One Step Closer To Comfort', 'https://ii2.pepperfry.com/media/wysiwyg/banners/Web_Beds_Rooms_Bedroom_04_2X_29042022.jpg', 'Woolleann', 10.00, 1, 200, '2018-03-10 19:42:02');
INSERT INTO "public"."product_info" VALUES ('C0003', 2, '2018-03-10 12:12:46', 'Grab it', 'https://ii1.pepperfry.com/media/wysiwyg/banners/happy_customer_block_2_2906_0222.png', 'Round Chair', 22.00, 0, 222, '2018-03-10 12:12:46');
INSERT INTO "public"."product_info" VALUES ('D0001', 3, '2018-03-10 06:51:03', 'Comfort Zone', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Sofasrecliners_irb_web_24012022_2x_4.jpg', 'Two Seater Sofa', 1.00, 0, 100, '2018-03-10 12:04:13');
INSERT INTO "public"."product_info" VALUES ('B0002', 0, '2018-03-10 10:35:43', 'Have a Pleasent Sleep', 'https://ii1.pepperfry.com/media/wysiwyg/banners/Web_Beds_Trends_02_2X_29042022.jpg', 'Easylift', 20.00, 0, 195, '2018-03-10 10:35:43');
INSERT INTO "public"."product_info" VALUES ('C0001', 2, '2018-03-10 12:09:41', 'Grab a Chair', 'https://ii1.pepperfry.com/media/wysiwyg/banners/Testimonial_web_261221_7.jpg', 'Wooden Chair', 10.00, 0, 109, '2018-03-10 12:09:41');
INSERT INTO "public"."product_info" VALUES ('C0002', 2, '2018-03-10 12:11:51', 'Grab Your Chair', 'https://ii2.pepperfry.com/media/wysiwyg/banners/Testimonial_web_261221_9.jpg', 'Office Chair', 13.00, 0, 108, '2018-03-10 12:11:51');
INSERT INTO "public"."product_info" VALUES ('B0001', 0, '2018-03-10 06:44:25', 'Grab Your Sleep', 'https://ii2.pepperfry.com/media/wysiwyg/banners/Web_Beds_Rooms_Bedroom_01_2X_29042022.jpg', 'MyBed', 30.00, 0, 96, '2018-03-10 06:44:25');
INSERT INTO "public"."product_info" VALUES ('B0004', 0, '2018-03-10 10:39:29', 'Have a Nice Sleep', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Beds_Room_Block_Mattresses_web_24012022_1.jpg', 'My Zone', 30.00, 0, 199, '2018-03-10 10:39:32');
INSERT INTO "public"."product_info" VALUES ('B0005', 0, '2018-03-10 10:40:35', 'My Comfort Zone', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Web_Beds_Trends_04_2X_29042022.jpg', 'Spine Loving', 30.00, 0, 199, '2018-03-10 10:40:35');
INSERT INTO "public"."product_info" VALUES ('D0002', 3, '2018-03-10 12:08:17', 'My Comfort Space', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Sofasrecliners_irb_web_24012022_2x_1.jpg', 'Three Seater Sofa', 2.00, 0, 200, '2018-03-10 12:08:17');
INSERT INTO "public"."product_info" VALUES ('F0001', 1, '2018-03-10 12:15:05', 'Make Your Path', 'https://ii2.pepperfry.com/media/wysiwyg/banners/Flooring_Style_Web_2X_2_17032022.jpg', 'Cotton Carpets', 4.00, 0, 57, '2018-03-10 12:15:10');
INSERT INTO "public"."product_info" VALUES ('F0002', 1, '2018-03-10 12:16:44', 'My Foot Prints', 'https://ii3.pepperfry.com/media/wysiwyg/banners/Flooring_Trends_Web_2X_4_17032022.jpg', 'Hallway', 20.00, 0, 22, '2018-03-10 12:16:44');


-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO "public"."users" VALUES (2147483641, 't', '3200 West Road', 'customer1@email.com', 'customer1', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', '123456789', 'ROLE_CUSTOMER');
INSERT INTO "public"."users" VALUES (2147483642, 't', '2000 John Road', 'manager1@email.com', 'manager1', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', '987654321', 'ROLE_MANAGER');
INSERT INTO "public"."users" VALUES (2147483643, 't', '222 East Drive ', 'employee1@email.com', 'employee1', '$2a$10$PrI5Gk9L.tSZiW9FXhTS8O8Mz9E97k2FZbFvGFFaSsiTUIl.TCrFu', '123123122', 'ROLE_EMPLOYEE');

-- ----------------------------
-- Records of cart
-- ----------------------------
INSERT INTO "public"."cart" VALUES (2147483641);
INSERT INTO "public"."cart" VALUES (2147483642);
INSERT INTO "public"."cart" VALUES (2147483643);
INSERT INTO "public"."cart" VALUES (2147483645);


