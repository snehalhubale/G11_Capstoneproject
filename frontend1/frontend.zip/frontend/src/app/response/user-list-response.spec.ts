import { UserListResponse } from './user-list-response';

describe('UserListResponse', () => {
  it('should create an instance', () => {
    expect(new UserListResponse()).toBeTruthy();
  });
});
