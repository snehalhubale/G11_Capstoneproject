import { WishList } from './wish-list';

describe('WishList', () => {
  it('should create an instance', () => {
    expect(new WishList()).toBeTruthy();
  });
});
