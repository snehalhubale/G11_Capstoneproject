import { ProductInfoMain } from "./product-info-main";
import { User } from "./User";

export class WishList {
    id : number;
    user : User;
    createdDate : Date;
    product : ProductInfoMain

}
